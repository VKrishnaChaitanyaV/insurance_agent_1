import { Box, Grid } from "@mui/material"
import { ContactManagementForm } from "../../contact-management/contact-management-form"

export const BasicInfo = (props) => {
    return (

        <Box mr={2}>
            <Grid container mb={2}>
                <Grid item xs={10} component={"h4"}>
                    Basic information
                </Grid>
                
            </Grid>
            <ContactManagementForm data={props.data}></ContactManagementForm>
        </Box>
    )
}

/* 

<Box mr={2}>
            <Grid container mt={1}>
                <Grid item xs={10} component={"h4"}>
                    LEAD MANAGEMENT
                </Grid>
                <Grid item xs={2} component={"h5"} sx={{cursor:'pointer'}} mb={1}>
                <Button variant="contained" color="error">Logout</Button>
                </Grid>
            </Grid>
            <Container sx={{ border: "1px solid gray" }}>
                <h5>BASIC INFORMATION</h5>
                <Grid container>
                    <Grid item xs={2} mt={1}>
                        <FormControl>
                            <FormLabel>First Name</FormLabel>
                        </FormControl>
                    </Grid>
                    <Grid item xs={10} mt={1}>
                        <TextField type="text" fullWidth variant="outlined"></TextField>
                    </Grid>
                </Grid>
                <Grid container>
                    <Grid item xs={2} mt={1}>
                        <FormControl>
                            <FormLabel>Last Name</FormLabel>
                        </FormControl>
                    </Grid>
                    <Grid item xs={10} mt={1}>
                        <TextField type="text" fullWidth variant="outlined"></TextField>
                    </Grid>
                </Grid>
                <Box>
                        <Grid container>
                            <Grid item xs={2} mt={1}>
                        <FormLabel>Gender</FormLabel>
                        </Grid>
                        <Grid item xs={10}>
                        <RadioGroup>
                            <Grid container>
                                <Grid item xs={2}>
                                    <FormControlLabel control={<Radio></Radio>} value="male" label="Male"></FormControlLabel>
                                </Grid>
                                <Grid item xs={10}>
                                    <FormControlLabel control={<Radio></Radio>} value="Female" label="Female"></FormControlLabel>  
                                </Grid>
                            </Grid>   
                        </RadioGroup>
                        </Grid>
                        </Grid>
                    
                </Box>
                <Box>
                <Grid container>
                    <Grid item xs={2} mt={1}>
                    <InputLabel>DOB</InputLabel>
                    </Grid>
                    <Grid item xs={10} mt={1}>
                    <TextField type="date" fullWidth variant="standard"></TextField>
                    </Grid>
                    </Grid>
                </Box>
                <Box>
                <Grid container>
                    <Grid item xs={2} mt={1}>
                    <InputLabel>Email</InputLabel>
                    </Grid>
                    <Grid item xs={10} mt={1}>
                    <TextField type="email" fullWidth variant="outlined"></TextField>
                    </Grid>
                    </Grid>
                </Box>
                <Box>
                <Grid container>
                    <Grid item xs={2} mt={1}>
                    <InputLabel>Occupation</InputLabel>
                    </Grid>
                    <Grid item xs={10} mt={1}>
                    <TextField type="text" fullWidth variant="outlined"></TextField>
                    </Grid>
                    </Grid>
                </Box>
                <Box>
                <Grid container>
                    <Grid item xs={2} mt={1}>
                <FormLabel>Marital Status</FormLabel>
                </Grid>
                <Grid item xs={10} mt={1}>
                <Select fullWidth>
                    <MenuItem value="married">Married</MenuItem>
                    <MenuItem value="single">Single</MenuItem>
                    <MenuItem value="divorced">Divorced</MenuItem>
                    <MenuItem value="widow">Widow</MenuItem>
                </Select>
                </Grid>
                </Grid>
            </Box>
                <Box mb={1}>
                    <Button variant="contained" color="success">Save</Button>

                </Box>
            </Container>
        </Box>

*/