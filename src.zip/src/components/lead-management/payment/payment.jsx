import { Box } from "@mui/material"

export const Payment=()=>{
    return(
        <Box>
            
        </Box>
    )
}