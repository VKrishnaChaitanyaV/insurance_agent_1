import { Box, Button, Grid } from "@mui/material";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getContactsListById } from "../../../services/contact-management.service";
import { BasicInfo } from "../basic-info/basic-info";
import { Address } from "../address/address";
import { Nominee } from "../nominee/nominee";
import { Policy } from "../policy/policy";

export function LeadEdit() {

    const {id} = useParams();

    const [contactListItem, setContactListItem] = useState({});

    const [component, setComponent] = useState("");

    useEffect(()=>{
        if(id) {
            getContactsListById(id).then((res)=>{
                setContactListItem(res.data);
                setComponent("basicInfo");
            });

            
        }
    }, []);

    return (
        <Box>
            <Grid container mb={2}>
                <Grid item xs={10} component={"h3"}>
                    Edit LEAD
                </Grid>
            </Grid>
            <Button variant="contained" color="primary" sx={{marginRight:"10px"}} onClick={()=>{
                setComponent("basicInfo");
            }}>Basic Information</Button>
            <Button variant="contained" color="info" sx={{marginRight:"10px"}} onClick={()=>{
                setComponent("address");
            }}>Address</Button>
            <Button variant="contained" color="secondary" sx={{marginRight:"10px"}} onClick={()=>{
                setComponent("nominee")
            }}>Nominee Details</Button>
            <Button variant="contained" color="primary"sx={{marginRight:"10px"}} onClick={()=>{
                setComponent("policy")
            }}>Policy</Button>
            <Button variant="contained" color="success"sx={{marginRight:"10px"}}>Payment</Button>

            <Box mt={2}></Box>

            { component == "basicInfo" && contactListItem &&  <BasicInfo id={ id } data={contactListItem}></BasicInfo> }
           
            { component == "address" && <Address id={ id }></Address> }

            { component == "nominee" && <Nominee id={ id }></Nominee> }

            { component == "policy" && <Policy id={ id }></Policy> }

        </Box>
    )
}