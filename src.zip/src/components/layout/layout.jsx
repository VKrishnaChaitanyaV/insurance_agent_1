import { AppRouter } from '../../app.router';
import { AppRouter1 } from '../../app.router1';
import './layout.css';
import {Menu} from './menu/menu';
import { useNavigate} from 'react-router-dom';

export function Layout(props) {

    const navigate = useNavigate();

    function logout(){
        sessionStorage.removeItem("agent");
        navigate("/login");
    }

    return (
        <div className='maind'>
            <div className='h-5 bg-light row'>
                <div className='col-11'> </div>
                <div className='col-1'> 
                    <input type="button" className="btn btn-link" value="Logout" onClick={
                        ()=>{
                            logout()
                        }
                    }></input>
                </div>
            </div>
            <div className='h-92 row maind'>
                <div className='col-2 bg-light'>
                    <Menu></Menu>
                </div>
                <div className='col-10 bg-white'>
                    {
                        props.children
                    }
                </div>   

            </div>
        </div>
    )
}