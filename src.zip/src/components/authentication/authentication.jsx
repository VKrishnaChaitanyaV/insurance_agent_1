import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";



export const Authentication = (props) => {
   //Check user is logged in or not
    let isUserExists = false;
    const navigate = useNavigate();

    if(sessionStorage.getItem("agent")) {
        isUserExists = true;
    }

   //If routing is login/ registration then no need to check user logged in or not
    if(window.location.pathname == "/login" || window.location.pathname == "/registration") {
        return props.children;
    }

   //if user logged in navigate
   else if(isUserExists) {
        if(window.location.pathname == "/") {
          navigate("/lead-management"); //Load Component
          return <Navigate to="/lead-management"></Navigate>
        }
        return props.children;
   }   
   //if user not loggedin navigate to loginpage
   else {        
        navigate("/login"); //Load Component
        return <Navigate to="/login"></Navigate> //Change Routing
   }
   
}

/*

useNavigate: useNavigate is a react js functional hook, it is used to navigate the routing from script.

Navigation 2 types:
1. from link: <link to=""
2. useNavigate

*/