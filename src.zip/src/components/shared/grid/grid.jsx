import { Box, Grid } from "@mui/material";
import { GridCell } from "../grid-cell/grid-cell";
import { GridHeader } from "./grid-header/grid-header";
import { Button } from "bootstrap";
import { Delete, Edit } from "@mui/icons-material";

export function GridComponent(props){
    return(

        <Box>
            <GridHeader headers={props.headers} cellWidth={props.cellWidth}></GridHeader>
            
                {
                    props.data && props.data.map((item)=>
                        <Grid container>
                            {props.keys.map((key, index) =>
                                <Grid item xs={ props.cellWidth[index] }>
                                    <GridCell data={ item[key] }></GridCell>
                                </Grid>
                            )}

                            { props.showEditDelete &&
                                <Grid item xs={ 1 }>
                                    <Edit onClick={()=>{
                                        props.editGridItem(item)
                                    }}></Edit>
                                    <Delete></Delete>
                                </Grid>
                            }
                        </Grid>
                    )
                }
            
        </Box>
    )
}