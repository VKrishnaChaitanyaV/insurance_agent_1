
import React from "react";
import { Box, Card, CardContent, Button  } from '@mui/material';

export class CardComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    
    static getDerivedStateFromProps() {
        console.log("getDerivedStateFromProps");
       
    }

    shouldComponentUpdate() {
        console.log("shouldComponentUpdate");
        return true;
    }

    getSnapshotBeforeUpdate() {
        console.log("getSnapshotBeforeUpdate");
    }

    componentDidMount() {
        console.log("componentDidMount");
    }

    componentDidUpdate() {
        console.log("ComponentDidUpdate");
    }

    componentWillUnmount() {
        //alert("Unloading");
    }

    render() {
        return (
            <Box>
                <Card sx={{width:"200px"}}>
                    <CardContent>
                        <Box component="h2">
                            {
                                this.props.header
                            }
                        </Box>
                        <Box>
                            Total {this.props.header}: {this.props.count}
                        </Box>
                        <Box>
                            <Button variant="outlined" onClick={
                                ()=>{
                                    this.props.goto()
                                }
                            }> Go to {this.props.header}</Button>
                        </Box>                   
                    </CardContent>   
                </Card>
            </Box>
        )
    }
}