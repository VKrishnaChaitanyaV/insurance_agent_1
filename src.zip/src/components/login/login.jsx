import { Box, Button, Container, FormControl, Input, InputLabel, TextField } from "@mui/material"
import { useEffect, useState, useRef } from "react";
import { Link, useNavigate } from "react-router-dom"
import { getAgents } from "../../services/agent-registration.service";

export const Login =()=>{

    const [agents, setAgents] = useState();
    const [isFormValid, setIsFormValid] = useState(true);
    const [isEmailValid, setIsEmailValid] = useState(true);
    const [isPasswordValid, setIsPasswordValid] = useState(true);
    const emailRef = useRef("");
    const passwordRef = useRef("");

    const navigate = useNavigate();

    function checkUser() {

        let isValid = validateFields();
        setIsFormValid(isValid);

        if(isValid) {
            //Send user name, password to api and get valid user/ not. for JSON server get all the users and check logged in user exists or not.
        
            let res = agents.find((item, index, arr)=> item.email == emailRef.current.value && item.password == passwordRef.current.value);

            sessionStorage.setItem("agent", JSON.stringify(res));

            navigate("/dashboard");
        }

    }

    function validateFields() {
        let isValid = true;
        isValid = validateEmail();

        isValid = validatePassword();
        return isValid;
    }

    function validateEmail() {
        let isEmailValid = true;
        if(emailRef.current.value == ""){
            isEmailValid = false;
        }
        setIsEmailValid(isEmailValid);
        return isEmailValid;
    }

    function validatePassword() {
        let isPasswordValid = true;
        if(passwordRef.current.value == "") {
            isPasswordValid = false;
        }
        setIsPasswordValid(isPasswordValid);
        return isPasswordValid;
    }

    useEffect(()=>{
        getAgentsList();
    }, []);

    function getAgentsList() {
        getAgents().then((res)=>{
            //alert(JSON.stringify(res.data));
            setAgents(res.data);
        });
    }

    return(
    <Box>
        <Container maxWidth="sm" sx={{border:"1px solid gray", padding:"5px"}}>
            <Box component="h2">Login</Box>
                <Box mt={3}>
                    <FormControl fullWidth>
                        <InputLabel>Email Address</InputLabel>
                        <Input inputRef={emailRef} onChange={()=> validateEmail()}></Input>
                    </FormControl>
                    { isEmailValid == false && <div className="text-danger">Please Enter Email Address</div> }
                </Box>
                <Box mt={3}>
                    <FormControl fullWidth>
                        <InputLabel>Enter Password</InputLabel>
                        <Input type="password" inputRef={passwordRef} onChange={()=> validatePassword()}></Input>
                    </FormControl>
                    {  isPasswordValid == false && <div className="text-danger">Please Enter Password</div> }
                </Box>
                <Box mt={3}>
                    <Button variant="contained" onClick={()=>{
                        checkUser()
                    }}>Login</Button>
                </Box>
                <Box>
                    For New Agent Register Here
                    <Link to="/registration"> Registration
                    </Link>
                </Box>
        </Container>
    </Box>
    )
}
