
import { Box, Container, InputLabel, Grid, FormControl, Input, TextField, Radio, RadioGroup, FormControlLabel, FormLabel, Select, MenuItem, Checkbox, Button } from "@mui/material"
import { saveAgent } from "../../services/agent-registration.service";
import { useRef } from "react";
import { useForm } from "react-hook-form";


export const Registration = () => {

    // const firstNameRef = useRef("");
    // const lastNameRef = useRef("");
    // const emailRef = useRef("");
    // const dobRef = useRef("");
    // const genderMaleRef = useRef("");
    // const genderFemaleRef = useRef("");
    // const qualifationRef = useRef("");
    const passwordRef = useRef("");
    const confirmPasswordRef = useRef("");
    // const termsRef = useRef("");

    const {
        register,
        watch,
        handleSubmit,
        formState: { errors },
      } = useForm();

    function addAgent(user) {
    
        // let genderval = "";
        // if(genderMaleRef.current.checked) {
        //     genderval = "male";
        // }
        // else if(genderFemaleRef.current.checked) {
        //     genderval = "female";
        // }

        // let user = {
        //     "firstName": firstNameRef.current.value,
        //     "lastName": lastNameRef.current.value,
        //     "email": emailRef.current.value,
        //     "dob": dobRef.current.value,
        //     "gender": genderMaleRef.current.checked ? "male" : "female",
        //     "qualification": qualifationRef.current.value,
        //     "password": passwordRef.current.value
        // }

        // let data = {
        //     method: "POST",
        //     headers: {
        //         "content-type": "application/json"
        //     },
        //     body: JSON.stringify(user)
        // }
        
        saveAgent(user).then(res=>{
            alert("User Added");
        });
    }

    return (
       <Box mt={1}>
            <Container maxWidth="sm" sx={{border: "1px solid gray"}}>
                <Box component={"h3"}>Agent Registration</Box>
                <form onSubmit={handleSubmit((data) => addAgent(data))}>
                    <Grid container>
                        <Grid item md={6} xs={12} mt={2}>
                            <FormControl fullWidth>
                                <InputLabel>First Name</InputLabel>
                                <Input {...register('fistName', { required: true, minLength: 3, maxLength: 10 })}></Input>
                            </FormControl>
                            { errors.fistName && errors.fistName.type == 'required' && <div className="text-danger">FirstName is required</div> }
                            { errors.fistName && errors.fistName.type == 'minLength' && <div className="text-danger">Minimum 3 chars required</div> }
                            { errors.fistName && errors.fistName.type == 'maxLength' && <div className="text-danger">Max 10 chars only</div> }
                        </Grid>
                        <Grid item md={6} xs={12} mt={2}>
                            <FormControl fullWidth>
                                <InputLabel>Last Name</InputLabel>
                                <Input {...register('lastName', { required: true })}></Input>
                                { errors.lastName && errors.lastName.type == 'required' && <div className="text-danger">LastName is required</div> }
                            </FormControl>
                        </Grid>
                    </Grid>

                    <Box mt={2}>
                        <TextField type="email" fullWidth label="Email" variant="standard" {...register('email', { required: true })}></TextField>
                        { errors.email && errors.email.type == 'required' && <div className="text-danger">Email is required</div> }
                    </Box>

                    <Box mt={2}>
                        <InputLabel>DOB</InputLabel>
                        <TextField type="date" fullWidth variant="standard"{...register('dob')}></TextField>
                    </Box>

                    {/* <Box mt={2}>
                        <Radio name="gender" value="male"></Radio> Male
                        <Radio name="gender" value="female"></Radio> FeMale
                    </Box> */}

                    {/* <Box mt={2}>
                        <RadioGroup>
                            <Radio name="gender" value="male"></Radio> Male
                            <Radio name="gender" value="female"></Radio> FeMale
                        </RadioGroup>
                    </Box> */}

                    <Box mt={2}>
                        <FormControl>
                            <FormLabel>Gender</FormLabel>
                            <RadioGroup>
                                <FormControlLabel control={<Radio {...register('gender')}></Radio>} value="male" label="Male"></FormControlLabel>
                                <FormControlLabel control={<Radio {...register('gender')}></Radio>} value="female" label="FeMale"></FormControlLabel>
                            </RadioGroup>
                        </FormControl>
                    </Box>
                    
                    <Box mt={2}>
                        <FormLabel>Qualification</FormLabel>
                        <Select size="small" fullWidth {...register('qualification')}>
                            <MenuItem value="graduate">Graduate</MenuItem>
                            <MenuItem value="undergraduate">Under Graduate</MenuItem>
                        </Select>
                    </Box>

                    <Box mt={2}>
                        <TextField type="text" fullWidth label="Password" variant="standard" inputRef={passwordRef} {...register('password', { required: true })}></TextField>
                        { errors.password && errors.password.type == 'required' && <div className="text-danger">Password is required</div> }
                    </Box>

                    <Box mt={2}>
                        <TextField type="text" fullWidth label="Confirm Password" variant="standard" inputRef={confirmPasswordRef} {...register('confirmPassword', { required: true, validate: (value)=> value == watch('password') })}></TextField>
                        { errors.confirmPassword && errors.confirmPassword.type == 'required' && <div className="text-danger">Confirm Password is required</div> }
                        { errors.confirmPassword && errors.confirmPassword.type != 'required' && <div className="text-danger">Confirm password is not matched with password.</div> }
                        {/* { passwordRef.current.value != confirmPasswordRef.current.value  && <div className="text-danger">Password matched failed</div> } */}
                    </Box>

                    <Box mt={2}>
                        <Checkbox {...register('terms')}></Checkbox>
                        <FormLabel>Agree terms & Conditions.</FormLabel>
                    </Box>

                    <Box mt={2} mb={2}>
                        <Button type="submit" variant="contained" color="success">Register</Button>
                        <Button variant="contained" color="info" sx={{marginLeft: "5px"}}>Cancel</Button>
                    </Box>

                </form>
            </Container>
            
       </Box>
    )
}