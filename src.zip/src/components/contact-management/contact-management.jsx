import { Box, Button, Checkbox, Container, FormControl, FormControlLabel, FormLabel, Grid, Input, InputLabel, MenuItem, Radio, RadioGroup, Select, TextField } from "@mui/material"

import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { addContact, getContactsList, updateContact } from "../../services/contact-management.service";
import { GridComponent } from "../shared/grid/grid";
import { ContactManagementForm } from "./contact-management-form";
import { useContext } from 'react';
import {AgentContext} from '../../services/agent-context.service';


export const ContactManagement = () => {

    const [open, setOpen] = useState(false);

    const gridHeaders = ["Is Lead", "ID", "Fist Name", "Last Name", "Email", "Phone Number", "DOB",  "Gender", "Address"];
    const gridKeys = ["isLead","id", "firstName", "lastName", "email", "phoneNumber", "dob", "gender", "address"];
    const gridCellWidth = [1, 1, 2, 1, 2, 1, 1, 1, 1];

    const [contactList, setContactList] = useState([]);
    const [contactListItem, setContactListItem] = useState({});

    const handleClose = () => {
        setOpen(false);
    }

    const agent = useContext(AgentContext);
    alert(JSON.stringify(agent));

    function saveContactFormData(data) {
        if(data.id !=0) {
            data = {...data, updatedDate: new Date()}
            updateContact(data.id, data).then((res)=>{
                alert("Contact Updated");
                setOpen(false);
                getContactList();
            });
        }
        else {
            delete data.id;
            data = {...data, createddate: new Date()}
            data = {...data, updatedDate: null}
            addContact(data).then((res)=>{
                alert("Contact Added to List.");
                setOpen(false);
                getContactList();
            });
        }
        
    }

    function getContactList() {
        getContactsList().then((res)=>{
            setContactList(res.data);
        });
    }

    useEffect(()=>{
        getContactList();
    }, []);

    return (
        <Box mr={2}>
            <Grid container mb={2}>
                <Grid item xs={10} component={"h3"}>
                    CONTACT MANAGEMENT
                </Grid>
                <Grid item xs={2} component={"h5"} sx={{ cursor: 'pointer' }} mt={1}>
                    <Button variant="contained" color="error" onClick={() => {
                        setOpen(true);
                        setContactListItem({});
                    }} data={contactListItem}>Add Contact</Button>
                </Grid>
            </Grid>

            <GridComponent headers={gridHeaders} keys={gridKeys} data={contactList} cellWidth={gridCellWidth} showEditDelete={true}
                editGridItem={(item)=>{
                    setContactListItem(item);
                    setOpen(true);
                }}
            ></GridComponent>

            <Dialog onClose={handleClose} open={open} fullWidth>
                <DialogTitle>Add Contact</DialogTitle>
                <ContactManagementForm closePopup={() => {
                    setOpen(false);
                }} contactFormData={(data)=>{
                    saveContactFormData(data)
                }}
                data={contactListItem}
                ></ContactManagementForm>
            </Dialog>

            {/*  */}
        </Box>
    )
}

