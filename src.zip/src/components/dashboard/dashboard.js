import { Box, Card, CardContent, Grid } from "@mui/material";
import React from "react";
import { CardComponent } from "../shared/card/card";
import { getContactsList } from "../../services/contact-management.service";
import { Link } from "react-router-dom";
import { GridComponent } from "../shared/grid/grid";

export class Dashboard extends React.Component { //inheritance
    constructor(props) {
        console.log("Constructor");
        super(); //Base class constructor
        this.state = {
            contacts: 0,
            leads :0,
            contactsList:[],
            leadsList:[],
            gridHeaders : [ "ID", "Fist Name", "Last Name", "Email", "Phone Number", "DOB",  "Gender", "Address"],
            gridKeys : ["id", "firstName", "lastName", "email", "phoneNumber", "dob", "gender", "address"],
            gridCellWidth : [1, 1, 1, 2, 1, 2, 1, 1]
        }

        
    }

    componentDidMount(){
        this.getDashboardData();
    } 

    async getDashboardData(){
        let _contacts = await getContactsList();

        let r = _contacts.data.sort((a,b)=>new Date(b.createddate)-new Date(a.createddate));

        this.setState({
            contactsList: r.slice(0, 5)
        });

        this.setState({
            leadsList: r.filter(item=>item.isLead==true).slice(0, 5)
        });

        this.setState({
            contacts: _contacts.data.length
        });

        this.setState({
            leads: _contacts.data.filter(item=>item.isLead==true).length
        })
    }
    

    render() {
        console.log("Render");
        return (
            <Box>
                <Card>
                    <CardContent>
                        {/* Contacts Card */}
                        <Box component="h2">
                            Dashboard
                        </Box>
                        <Grid container>
                            <Grid item xs={3}>
                                <CardComponent header="Contacts" count={this.state.contacts} goto={()=>{
                                        window.location.href="http://localhost:4000/contact-management"
                                    }
                                }></CardComponent>
                            </Grid>
                            <Grid item xs={3}>
                                <CardComponent  header="Leads" count={this.state.leads} goto={()=>{
                                        window.location.href="http://localhost:4000/lead-management"
                                    }
                                }></CardComponent>
                            </Grid>
                        </Grid>
                        
                        <Card>
                            <Box component="h2">Recent Contacts</Box>
                            <CardContent>
                                <GridComponent headers={this.state.gridHeaders} keys={this.state.gridKeys} data={this.state.contactsList} cellWidth={this.state.gridCellWidth} showEditDelete={false}
                            ></GridComponent>
                            </CardContent>
                        </Card>
                        <Card>
                            <Box component="h2">Recent Leads</Box>
                            <CardContent>
                                <GridComponent headers={this.state.gridHeaders} keys={this.state.gridKeys} data={this.state.leadsList} cellWidth={this.state.gridCellWidth} showEditDelete={false}
                            ></GridComponent>
                            </CardContent>
                        </Card>
                        
                        
                    </CardContent>
                </Card>
            </Box>
        )
    }

}