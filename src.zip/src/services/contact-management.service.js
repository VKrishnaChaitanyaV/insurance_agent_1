
import { getData, saveData, updateData } from './context.service';

const url = "http://localhost:3000/ContactManagemenet/";

const addressurl = "http://localhost:3000/address/";

const nomineeurl = "http://localhost:3000/nominee/";

const packagesurl = "http://localhost:3000/packages/";

const policyUrl = "http://localhost:3000/policiy/";

export function getContactsList() {
    return getData(url);
}

export function getContactsListById(id) {
    return getData(url+id);
}

export function addContact(data) {
    return saveData(url, data);
}

export function updateContact(id, data) {
    return updateData(url, id, data);
}

export function saveAddress(data) {
    return saveData(addressurl, data);
}

export function getAddress() {
    return getData(addressurl);
}

export function updateAddress(data, id) {
    return updateData(addressurl, id, data);
}

export function saveNominee(data) {
    return saveData(nomineeurl, data);
}

export function getNominee() {
    return getData(nomineeurl);
}

export function updateNominee(data, id) {
    return updateData(nomineeurl, id, data);
}

//
export function getPackages() {
    return getData(packagesurl);
}

export function savePolicy(data) {
    return saveData(policyUrl, data);
}

export function getPolicy() {
    return getData(policyUrl);
}