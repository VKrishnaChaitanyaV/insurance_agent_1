
import { getData, saveData, updateData } from './context.service';

const url = "http://localhost:3000/agents/";

export function getAgents() {
    return getData(url);
}

export function saveAgent(data) {
    return saveData(url, data);
}

export function updateAgent(id, data) {
    return updateData(url, id, data);
}