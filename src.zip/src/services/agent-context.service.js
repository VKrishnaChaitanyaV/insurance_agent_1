
import React from 'react';

export const AgentContext = React.createContext();