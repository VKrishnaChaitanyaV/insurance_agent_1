import { Grid } from "@mui/material"


export const GridHeader=(props)=>{

    

    return(
        <Grid container>
                {
                    props.headers && props.headers.map((value, index, arr)=>HeaderCell(value, props.cellWidth[index]))
                }             

        </Grid>
    )
}

function HeaderCell(value, width){

    return(
        <Grid item xs={width} sx={{textAlign:"center", fontWeight:"bold", backgroundColor:"#D3D3D3", padding:"5px",border:"1px solid gray"}}>{value}</Grid>
    )
}